export class SignupData {
  username:string|any;
  password:string|any;
  firstname:string|any;
  lastname:string|any;
  email:string|any;
  contact:string|any;
  role:string|any; 
}
