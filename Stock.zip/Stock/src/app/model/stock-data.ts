export class StockData {
    price: number;
    CompanyCode:number
    id:number;
    timeStamp:Date;
}
