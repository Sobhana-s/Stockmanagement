import { AddcompanyData } from './addcompany-data';

describe('AddcompanyData', () => {
  it('should create an instance', () => {
    expect(new AddcompanyData()).toBeTruthy();
  });
});
