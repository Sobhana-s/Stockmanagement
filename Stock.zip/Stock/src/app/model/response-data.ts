export class ResponseData {
    id:string|any;
    username: string | any;
    email: string | any;
    password: string | any;
    roles:any[]|any;
}
