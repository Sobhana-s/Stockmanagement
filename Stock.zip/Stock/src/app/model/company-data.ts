

export class CompanyData {
    CompanyCode :number |any;
      CompanyName:string|any;
      CompanyCEO:string|any;
      CompanyTurnover:number|any;
      CompanyWebsite:string|any;
    stockExchange:string|any;
    LatestStockPrice : number |any;
	
}
