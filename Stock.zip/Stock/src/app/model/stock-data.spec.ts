import { StockData} from './stock-data';

describe('StockData', () => {
  it('should create an instance', () => {
    expect(new StockData()).toBeTruthy();
  });
});
