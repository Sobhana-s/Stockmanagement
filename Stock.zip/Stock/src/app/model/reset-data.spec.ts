import { ResetData } from './reset-data';

describe('ResetData', () => {
  it('should create an instance', () => {
    expect(new ResetData()).toBeTruthy();
  });
});
