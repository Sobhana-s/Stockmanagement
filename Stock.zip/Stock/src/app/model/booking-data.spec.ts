import { CompanyData } from './company-data';

describe('CompanyData', () => {
  it('should create an instance', () => {
    expect(new CompanyData()).toBeTruthy();
  });
});
