export class AddcompanyData {
    
      CompanyName:string|any;
      CompanyCEO:string|any;
      CompanyTurnover:number|any;
      CompanyWebsite:string|any;
      stockExchange?:string|any;
   
}
