import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

import { AuthapiService } from '../apiService/authapi.service';
import { CompanyapiService } from '../apiService/companyapi.service';
import { AddcompanyData } from '../model/addcompany-data';


@Component({
  selector: 'app-add-company',
  templateUrl: './add-company.component.html',
  styleUrls: ['./add-company.component.css']
})
export class AddCompanyComponent {
  companyForm: FormGroup | any;
  addCompanySuccess: boolean | null = false;
  loading: boolean = false;
  finalToken = this.authService.getUserToken();
  isAddMode:boolean = true;
  companyData:any={};
  constructor(private formBuilder: FormBuilder, 
    private authService: AuthapiService, 
    private companyService: CompanyapiService,
    private route:ActivatedRoute) { }

  ngOnInit() {
    this.companyForm = this.formBuilder.group({
      companyName: ['', Validators.required],
      companyCEO: ['', Validators.required],
      companyTurnover: ['', Validators.required],
      companyWebsite: ['', Validators.required],
      stockExchange: ['', Validators.required],
     
    });
    this.route.queryParams.subscribe((params:any) =>{
      console.log(params);
      if(params.companyCode){
        this.isAddMode = !params
        this.companyData = params;
        this.companyForm.patchValue(params);
      }
    })
  }

  onSubmit() {
    if (this.companyForm.invalid) {
      this.loading = false;
      return;
    }

    const formData = this.companyForm.value;
    console.log(formData);
    const companyData: any = {
      companyName: formData.companyName,
      companyCEO: formData.companyCEO,
      companyTurnover: formData.companyTurnover,
      companyWebsite: formData.companyWebsite,
      stockExchange: formData.stockExchange
      
    };
    if(this.isAddMode){
      this.companyService.addCompany(companyData, this.finalToken).subscribe(res => {
        console.log(res);
        this.loading = true;
        this.addCompanySuccess = false;
      }, err => {
        console.log(err.error);
        this.loading = false;
        this.addCompanySuccess = true;
      });

    }
    if(!this.isAddMode){
      const cmpCode =this.companyData.companyCode;
      console.log(companyData)
      this.companyService.updateCompany(cmpCode,companyData, this.finalToken).subscribe(res => {
        console.log(res);
        this.loading = true;
        this.addCompanySuccess = false;
      }, err => {
        console.log(err.error);
        this.loading = false;
        this.addCompanySuccess = true;
      });

    }
    this.loading = false;
    this.companyForm.reset();
  }

}
