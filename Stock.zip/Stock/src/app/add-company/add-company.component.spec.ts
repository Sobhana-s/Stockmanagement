import { ComponentFixture, TestBed } from '@angular/core/testing';


import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AuthapiService } from '../apiService/authapi.service';

import { NavbarComponent } from '../navbar/navbar.component';
import { MatCardModule } from '@angular/material/card';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { FormGroup, FormsModule } from '@angular/forms';
import { AddCompanyComponent } from './add-company.component';
import { CompanyapiService } from '../apiService/companyapi.service';

describe('AddCompanyComponent', () => {
  let component: AddCompanyComponent;
  let fixture: ComponentFixture<AddCompanyComponent>;
  
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports:[HttpClientTestingModule,MatCardModule,MatToolbarModule,MatFormFieldModule,MatSelectModule,FormsModule],
  providers: [AuthapiService,CompanyapiService],
      declarations: [ AddCompanyComponent,NavbarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddCompanyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
