import { Component, OnInit, ViewChild } from '@angular/core';
import { CompanyapiService } from '../apiService/companyapi.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { AuthapiService } from '../apiService/authapi.service';
import { Location } from '@angular/common';
import { CompanyData } from '../model/company-data';


@Component({
  selector: 'app-view-companies',
  templateUrl: './view-companies.component.html',
  styleUrls: ['./view-companies.component.css']
})
export class ViewCompaniesComponent implements OnInit {
  companies: any[];
  username: string | any;
  dataSource = new MatTableDataSource<CompanyData>([]);
  editMode = true;
  finalToken = this.authService.getUserToken();
  isAdmin = false;
  loading = true; 
  searchText = "";


  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;

  constructor(private companyService: CompanyapiService, private router: Router, private formBuilder: FormBuilder, private authService: AuthapiService) { }

  selectedCompany: any;
  deleteCompany(company: any) {
    console.log('Delete company:', company);
    if(confirm("Are You Sure to delete '" + company.companyName +"' ")){
      this.companyService.deleteCompany(company.companyCode, this.finalToken).subscribe(res => {
        this.router.navigate(['/companies']);
        window.location.reload();
        }, err => {
        console.log(err);
      });

    }
   
  }
  editCompany(company:any): void {
    this.editMode = !this.editMode;
    this.selectedCompany = company;
    console.log(this.selectedCompany);
    this.router.navigate(['/addcompany'],{
      queryParams:this.selectedCompany
    })
  }

  ngOnInit() {
    this.isAdmin = this.authService.isRoleAdmin();
    
    this.username = localStorage.getItem('username');
    this.companyService.getAllCompanies(this.finalToken).subscribe(data => {
      this.companies = data;
    
    })
  }

  Search() {
    
    if (this.searchText !== "") {
      let searchValue = Number(this.searchText)

      this.companies = this.companies.filter((contact: any) => {
        console.log(typeof(contact.companyCode));
        return contact.companyCode === searchValue;
      });

    }
     else { 
      this.companyService.getAllCompanies(this.finalToken).subscribe(data => {

         this.companies = data;

             }, error => console.error(error));
       

     } 
  }
  inputValidator(event){
    if(this.searchText===""){
      this.companyService.getAllCompanies(this.finalToken).subscribe(data => {
        this.companies = data;
      }, error => console.error(error));
    }
  }


}

