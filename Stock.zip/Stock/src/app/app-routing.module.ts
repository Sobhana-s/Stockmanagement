import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ViewCompaniesComponent } from './view-companies/view-companies.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { ResetComponent } from './reset/reset.component';
import { AuthGuardService } from './apiService/auth-guard.service';
import { AddCompanyComponent } from './add-company/add-company.component';

import { NotfoundComponent } from './notfound/notfound.component';
import { ViewCompanyDetailsComponent } from './view-company-details/view-company-details.component';
import { StockComponent } from './stock/stock.component';

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: SignupComponent },
  { path: 'reset', component: ResetComponent },
  {
    path: 'companies', component: ViewCompaniesComponent,
    canActivate: [AuthGuardService],
    data: { allowedRoles: ['admin', 'user'] }
  },
  {
    path: 'addcompany', component: AddCompanyComponent,
    canActivate: [AuthGuardService],
    data: {
      allowedRoles: ['admin']
    }
  },
  {
    path: 'stock', component: StockComponent,
    canActivate: [AuthGuardService],
    data: {
      allowedRoles: ['admin']
    }
  },
  {
    path: 'search/:companyCode',
    component: ViewCompanyDetailsComponent,
    canActivate: [AuthGuardService], data: { allowedRoles: ['admin', 'user'] }
  },
  { path: '**', component: NotfoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
