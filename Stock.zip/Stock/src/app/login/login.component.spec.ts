import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginComponent } from './login.component';
import { AuthapiService } from '../apiService/authapi.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { MatCardModule } from '@angular/material/card';
import {MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';


describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let authService:AuthapiService;
  let router:Router;
  let httpMock: HttpTestingController;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports:[HttpClientTestingModule,MatCardModule,MatFormFieldModule, FormsModule,
        ReactiveFormsModule],
      providers: [AuthapiService],
      declarations: [ LoginComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    authService=TestBed.inject(AuthapiService);
    router=TestBed.inject(Router);
  });


  it('should create', () => {
    expect('component').toBeTruthy();
  });

  it('should login user sccessfully and navigate to companies',()=>
  {
    const MockLoginFormValue={ username: 'testuser', password: 'testpassword'};
    const mockResponse={token:'sampleToken',role:'user'}
    spyOn(authService,'loginUser').and.returnValue(
      {
        subscribe:(callback:any)=>callback(mockResponse),
      } as any);
    spyOn(localStorage,'setItem');
    spyOn(router,'navigate');
    component.onSubmit();
    expect(authService.loginUser).toHaveBeenCalledWith(MockLoginFormValue);
    expect(localStorage.setItem).toHaveBeenCalledWith('accesstoken','sampleToken');
    expect(localStorage.setItem).toHaveBeenCalledWith('role','user');
    expect(router.navigate).toHaveBeenCalledWith(['/companies']);
    expect(component.loginSuccess).toBe(true);
    expect(component.loading).toBe(false); 
    });

    it('should login admin sccessfully and navigate to addcompany',()=>
  {
    const MockLoginFormValue={ username: 'testuser', password: 'testpassword'};
    const mockResponse={token:'sampleToken',role:'admin'}
    spyOn(authService,'loginUser').and.returnValue(
      {
        subscribe:(callback:any)=>callback(mockResponse),
      } as any);
    spyOn(localStorage,'setItem');
    spyOn(router,'navigate');
    component.onSubmit();
    expect(authService.loginUser).toHaveBeenCalledWith(MockLoginFormValue);
    expect(localStorage.setItem).toHaveBeenCalledWith('accesstoken','sampleToken');
    expect(localStorage.setItem).toHaveBeenCalledWith('role','admin');
    expect(router.navigate).toHaveBeenCalledWith(['/addCompany']);
    expect(component.loginSuccess).toBe(true);
    expect(component.loading).toBe(false); 
    });

    it('should handle errors',()=>
    {
      const MockLoginFormValue={ username: 'testuser', password: 'testpassword'};
      spyOn(authService,'loginUser').and.returnValue({
        subscribe:(callback:any,errorCallback:any)=>errorCallback('sampleError'),
      } as any);
      spyOn(console,'error');
      component.onSubmit();
      expect(authService.loginUser).toHaveBeenCalledWith(MockLoginFormValue);
      expect(console.error).toHaveBeenCalledWith('sampleError');
      expect(component.loginSuccess).toBe(true);
      expect(component.loading).toBe(false); 
  });
});

