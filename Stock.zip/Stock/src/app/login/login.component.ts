import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthapiService } from '../apiService/authapi.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent  {
  loginForm: FormGroup | any;
  hidePassword: boolean = true;
  loginSuccess: boolean | null = null;
  loading:boolean = false;
  hide:boolean = true;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthapiService,
    private router:Router
  ) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  onSubmit() {
    if (this.loginForm.invalid) {
      this.loading = false;
      return;
    }
    this.loading = true;
    
    const formValues = this.loginForm.value;
    console.log(formValues);
    this.authService.loginUser(formValues).subscribe(
      (res) => {
        
        localStorage.setItem('accessToken', res.token);
        
        if(res.role==='user')
        {
          localStorage.setItem('role', 'user');
          console.log("User login Successfully");
          this.router.navigate(['/companies']);
        }
        else if(res.role==='admin')
        {
          localStorage.setItem('role', 'admin');
          console.log("Admin login Successfully");
          this.router.navigate(['/addcompany']);
        }
       
       
        this.loginSuccess = true;
        this.loading = false;
      },
      (err) => {
        this.loginSuccess = false;
        this.loading = false;
      }
    );
  }
  togglePasswordVisibility() {
    this.hidePassword = !this.hidePassword;
  }

  
}
