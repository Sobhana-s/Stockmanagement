import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { CompanyapiService } from './companyapi.service';

describe('CompanyapiService', () => {
  let service: CompanyapiService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [CompanyapiService]
    });
    service = TestBed.inject(CompanyapiService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should send a GET request to retrieve all companies', () => {
    const token = 'test-token';
    const testCompanyData =[{companyCode:101,companyName:'test',companyCEO:'mark',companyWebsite:'www.test.com',companyTurnover:'140000000',stockExchange:['NSE','BSE'],latestStockPrice:['234.09']}];

    service.getAllCompanies(token).subscribe((companies) => {
      expect(companies).toEqual(companies);
    });

    const req = httpMock.expectOne(service.companyServiceUrl + '/getAll');
    expect(req.request.method).toBe('GET');
    expect(req.request.headers.get('Authorization')).toBe(token);
    req.flush(testCompanyData);
  });

  it('should send a GET request to retrieve a company by company code', () => {
    const token = 'arvind-token';
    const companyCode = 1;
    const mockCompany={companyCode:123,companyName:'facebook',companyCEO:'mark',companyWebsite:'www.test.com',companyTurnover:'1200000000',stockExchange:['NSE','BSE'],latestStockPrice:['234.09']};

    service.getCompanyInfo(token, companyCode).subscribe((company) => {
      expect(company).toEqual(mockCompany);
    });

    const req = httpMock.expectOne(service.companyServiceUrl + `/info/${companyCode}`);
    expect(req.request.method).toBe('GET');
    expect(req.request.headers.get('Authorization')).toBe(token);
    req.flush(mockCompany);
  });
});
function companies(companies: any) {
  throw new Error('Function not implemented.');
}

