import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { StockData } from '../model/stock-data';
import { AuthapiService } from './authapi.service';

@Injectable({
  providedIn: 'root'
})
export class StockService {
  constructor(private http: HttpClient) { }
  private apiPostStock: string = `http://localhost:8081/v1.0/market/stock/add`;
  addStockByCode(cid: number, stock: StockData, token): Observable<StockData> {
    let options = {
      headers:{"Authorization":token}
    }
    return this.http.post<StockData>(`${this.apiPostStock}/${cid}`,stock,options);
  }
}