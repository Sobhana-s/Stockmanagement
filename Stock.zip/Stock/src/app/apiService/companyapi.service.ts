import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CompanyData } from '../model/company-data';
import { AddcompanyData } from '../model/addcompany-data';

@Injectable({
  providedIn: 'root'
})
export class CompanyapiService {

  
  companyServiceUrl = 'http://localhost:8081/v1.0/market/company';

  constructor(private http:HttpClient) { }
  //get all companies(admin+customer)
  getAllCompanies(token:string){
    let options = {
      headers:{"Authorization":token}
    }
    return this.http.get<any[]>(this.companyServiceUrl+"/getAll",options);
  }

  //get the company by companycode
  getCompanyInfo(token:string,CompanyCode:number){
    let options = {
      headers:{"Authorization":token}
    }
    return this.http.get<any>(this.companyServiceUrl+`/info/${CompanyCode}`,options);//fix url here--match api gateway
  }

  //admin only : delete company by it's id
  deleteCompany(CompanyCode:number,token:string){
    let options = {
      headers:{"Authorization":token}
    }
    return this.http.delete<any>(this.companyServiceUrl+`/delete/${CompanyCode}`,options);
  }

  //update the company
  updateCompany(CompanyCode:number,company:CompanyData,token:string){
    let options = {
      headers:{"Authorization":token}
    }

    return this.http.put<any>(this.companyServiceUrl+`/put/${CompanyCode}`,company,options);
  }
  //add company
  addCompany(company:AddcompanyData,token:string){
    let options = {
      headers:{"Authorization":token}
    }
    return this.http.post<AddcompanyData>(this.companyServiceUrl+"/register",company,options);
  }

}
