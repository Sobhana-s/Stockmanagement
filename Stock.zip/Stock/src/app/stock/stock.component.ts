import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthapiService } from '../apiService/authapi.service';
import { StockService } from '../apiService/stock.service';
import { StockData } from '../model/stock-data';

@Component({
  selector: 'app-stock',
  templateUrl: './stock.component.html',
  styleUrls: ['./stock.component.css']
})
export class StockComponent {
  stockForm: FormGroup | any;
  finalToken = this.authService.getUserToken();
  loading: boolean;
  formData: any;
  stockData: any;

  constructor(private authService: AuthapiService,
    private formBuilder: FormBuilder,
    private stockService: StockService) {
  }

  data: {} | any;
  res:any = {}
  stocklist: Array<StockData> = [];
  ngOnInit() {
    this.stockForm = this.formBuilder.group({
      companyCode: ['', Validators.required],
      price: ['', Validators.required]
    });
  }
  onSubmit() {
    if (this.stockForm.invalid) {
      this.loading = false;
      return;
    }
    const formData = this.stockForm.value;
    this.stockData = {
      companyCode: formData.companyCode,
      price: formData.price
    };
    this.stockService.addStockByCode(this.stockData.companyCode, this.stockForm.value,this.finalToken).subscribe(data => {
      this.res = data
      alert("Stock Updated Successfully!")
      this.stockForm.reset();
    },
      error => {
        console.log(error);
      })


  }
}