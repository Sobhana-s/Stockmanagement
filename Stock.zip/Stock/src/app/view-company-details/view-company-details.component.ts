import { formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthapiService } from '../apiService/authapi.service';
import { CompanyapiService } from '../apiService/companyapi.service';
import { CompanyData } from '../model/company-data';

@Component({
  selector: 'app-view-company-details',
  templateUrl: './view-company-details.component.html',
  styleUrls: ['./view-company-details.component.css']
})
export class ViewCompanyDetailsComponent implements OnInit {
  routeparam: any;
  dataSource = new MatTableDataSource<CompanyData>([]);
  finalToken = this.authService.getUserToken();
  companyData:any={};
  stockData:any=[];
  duplicateData:any[];
  columnChartOptions:any= {};
  data=[]
  minStock=0;
  maxStock = 0;
  averageStock = 0.0;
  searchId="";
  fromDate="";
  toDate="";
  dateRange="";
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private companyService: CompanyapiService,
    private authService: AuthapiService) {}

  ngOnInit(){
    this.route.params.subscribe((params: any) => {
      this.routeparam = params.companyCode
    });

    this.companyService.getCompanyInfo(this.finalToken,this.routeparam,).subscribe(res => {
      this.companyData = res;
      this.stockData = res.previousStockPrices;
      this.stockData.push(res.latestStockPrice);
      this.minStock = this.getMinPrice();
      this.maxStock = this.getMaxPrice();
      this.averageStock =this.getAverageStock(this.stockData);
     
      for(let val of this.stockData) {
        let obj:any={};
        obj.label = formatDate(val.timeStamp,'yyyy-MM-dd','en-Us');
        obj.y = val.price;
        this.data.push(obj);
      }
    });  

    this.columnChartOptions = {
      animationEnabled: true,
      title: {
        text: 'Angular Column Chart in Material UI Tabs',
      },
      data: [
        {
          // Change type to "doughnut", "line", "splineArea", etc.
          type: 'column',
          dataPoints: this.data,
        },
      ],
    };
   }

  getMinPrice(){
    if(this.stockData.length===0)
    {
      return null;
    }
  
    return this.stockData.reduce((min, b) => Math.min(min, b.price), this.stockData[0].price);
  }
  
  getMaxPrice(){
   
    return this.stockData.reduce((max, b) => Math.max(max, b.price), this.stockData[0].price);
  }
  getAverageStock(arr){
    const { length } = arr;
    return this.stockData.reduce((acc, val) => {
      return acc + (val.price/length);
   }, 0).toFixed(3);
  }
  applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  Search() {
    
    if (this.searchId !== "") {
      let searchValue = Number(this.searchId)
      this.stockData= this.stockData.filter((contact: any) => {
        console.log(typeof(contact.timeStamp));
        return contact.id === searchValue;
      });
    } 
    else { 
      this.companyService.getCompanyInfo(this.finalToken,this.routeparam,).subscribe(data => {
        this.stockData = data.previousStockPrices;
        this.stockData.push(data.latestStockPrice);
             }, error => console.error(error));
     } 
  }
  inputValidator(event){
    if(this.searchId===""){
      this.companyService.getCompanyInfo(this.finalToken,this.routeparam,).subscribe(data => {
        this.stockData = data.previousStockPrices;
      this.stockData.push(data.latestStockPrice);
      }, error => console.error(error));
    }
  }


  dateFilter(){
    if (this.fromDate !== ""&&this.toDate!=="") {
       this.fromDate=formatDate(this.fromDate,'yyyy-MM-dd','en-Us');
       this.toDate=formatDate(this.toDate,'yyyy-MM-dd','en-Us');

      this.stockData = this.stockData.filter((contact: any) => {
        
        contact.timeStamp=formatDate(contact.timeStamp,'yyyy-MM-dd','en-Us')
        console.log("*************",typeof(contact.timeStamp));
        return contact.timeStamp>= this.fromDate&& contact.timeStamp<=this.toDate;
      });
      this.minStock = this.getMinPrice();
      this.maxStock = this.getMaxPrice();
      this.averageStock =this.getAverageStock(this.stockData);
      console.log(this.stockData);
      
    } 
      err => {
        console.log(err);
     } 
  } 
}
